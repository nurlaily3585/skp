<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
    <p class="mb-4">Informasi detail kegiatan baru saya.</p>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><?= $title; ?></h6>
        </div>
        <div class="card-body">
            <div class="mb-3">
                <label for="formGroupExampleInput" class="form-label">Example label</label>
                <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Example input placeholder">
            </div>
            <div class="mb-3">
                <label for="formGroupExampleInput2" class="form-label">Another label</label>
                <input type="text" class="form-control" id="formGroupExampleInput2" placeholder="Another input placeholder">
            </div>
            <div class="mb-3">
                <label for="formGroupExampleInput3" class="form-label">Another label</label>
                <div class="dropdown mb-4">
                    <button class="btn btn-outline-gray dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Pilih
                    </button>
                    <div class="dropdown-menu animated--fade-in" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="#">Action</a>
                        <a class="dropdown-item" href="#">Another action</a>
                        <a class="dropdown-item" href="#">Something else here</a>
                    </div>
                </div>
            </div>
            <div class="mb-3">
                <a href="<?= base_url('hmj/mendaftar'); ?>" class="btn btn-primary btn-icon-split">
                    <span class="icon text-white-50">
                        <i class="fas fa-check-double"></i>
                    </span>
                    <span class="text">Submit</span>
                </a>
            </div>

            <!-- Ini baru -->
            <!-- <form method="POST" action="<?= base_url('Hmj/daftarKegiatan'); ?>"> -->
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <a class="nav-link active" id="1-tab" data-toggle="tab" href="#detail" role="tab" aria-controls="1" aria-selected="true">Detail Kegiatan</a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" id="2-tab" data-toggle="tab" href="#pendanaan" role="tab" aria-controls="2" aria-selected="false">Pendanaan</a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" id="3-tab" data-toggle="tab" href="#jawab" role="tab" aria-controls="3" aria-selected="false">Pertanggungan Jawab</a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" id="4-tab" data-toggle="tab" href="#penanggung" role="tab" aria-controls="4" aria-selected="false">Penanggung Jawab</a>
                </li>
            </ul>
            <!-- Tab Pertama -->







        </div>
        <script type="text/javascript">
            var rupiah = document.getElementById('rupiah');
            rupiah.addEventListener('keyup', function(e) {
                // tambahkan 'Rp.' pada saat form di ketik
                // gunakan fungsi formatRupiah() untuk mengubah angka yang di ketik menjadi format angka
                rupiah.value = formatRupiah(this.value, 'Rp. ');
            });

            /* Fungsi formatRupiah */
            function formatRupiah(angka, prefix) {
                var number_string = angka.replace(/[^,\d]/g, '').toString(),
                    split = number_string.split(','),
                    sisa = split[0].length % 3,
                    rupiah = split[0].substr(0, sisa),
                    ribuan = split[0].substr(sisa).match(/\d{3}/gi);

                // tambahkan titik jika yang di input sudah menjadi angka ribuan
                if (ribuan) {
                    separator = sisa ? '.' : '';
                    rupiah += separator + ribuan.join('.');
                }

                rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
                return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
            }
        </script>
    </div>