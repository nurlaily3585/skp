<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Hmj extends CI_Controller
{
    public function index()
    {
        $data['title'] = 'Beranda';
        $data['user'] = $this->db->get_where('tb_user', ['email' => $this->session->userdata('email')])->row_array();
        // echo 'Selamat Datang ' . $data['user']['firstname'] . ' ' . $data['user']['lastname'];

        // $data['hasil'] = $this->M_Hmj->Jum_mahasiswa_perjurusan();
        // $data['total_kegiatan'] = $this->M_Hmj->hitungJumlahKegiatan();
        // $data['total_kegiatan_baru'] = $this->M_Hmj->hitungJumlahKegiatanBaru();


        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('hmj/index', $data);
        $this->load->view('templates/footer');
    }
    public function v_riwayat()
    {
        $data['title'] = 'Riwayat Kegiatan';
        $data['user'] = $this->db->get_where('tb_user', ['email' => $this->session->userdata('email')])->row_array();
        // echo 'Selamat Datang ' . $data['user']['firstname'] . ' ' . $data['user']['lastname'];
        // $data['kegiatan'] = $this->session->userdata('email')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('hmj/v_riwayat', $data);
        $this->load->view('templates/footer');
    }
    public function v_list()
    {
        $data['title'] = 'Daftar Kegiatan';
        $data['user'] = $this->db->get_where('tb_user', ['email' => $this->session->userdata('email')])->row_array();
        // echo 'Selamat Datang ' . $data['user']['firstname'] . ' ' . $data['user']['lastname'];

        // $data['kegiatan'] = $this->db->get_where('tb_kegiatan', ['status' => 1])->result_array();
        $data['kegiatan'] = $this->db->get('tb_kegiatan')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('hmj/v_list', $data);
        $this->load->view('templates/footer');
    }
    public function v_add()
    {
        $data['title'] = 'Kegiatan Saya';
        $data['user'] = $this->db->get_where('tb_user', ['email' => $this->session->userdata('email')])->row_array();
        // echo 'Selamat Datang ' . $data['user']['firstname'] . ' ' . $data['user']['lastname'];
        $data['kegiatan'] = $this->db->get_where('tb_kegiatan', ['accountCreated' => $this->session->userdata('email')])->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('hmj/v_add', $data);
        $this->load->view('templates/footer');
    }
    public function v_ikuti()
    {
        $data['title'] = 'Detail Kegiatan';
        $data['user'] = $this->db->get_where('tb_user', ['email' => $this->session->userdata('email')])->row_array();
        // echo 'Selamat Datang ' . $data['user']['firstname'] . ' ' . $data['user']['lastname'];
        $data['kegiatan'] = $this->db->get_where('tb_kegiatan', ['accountCreated' => $this->session->userdata('email')])->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('hmj/v_ikuti', $data);
        $this->load->view('templates/footer');
    }
    public function v_baru()
    {
        $data['title'] = 'Kegiatan Baru';
        $data['user'] = $this->db->get_where('tb_user', ['email' => $this->session->userdata('email')])->row_array();
        // echo 'Selamat Datang ' . $data['user']['firstname'] . ' ' . $data['user']['lastname'];
        $data['kegiatan'] = $this->db->get_where('tb_kegiatan', ['accountCreated' => $this->session->userdata('email')])->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('hmj/v_baru', $data);
        $this->load->view('templates/footer');
    }
}
